﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","sk",{button:"Vložte kód Snippet-u",codeContents:"Obsah kódu",emptySnippetError:"Snippet kódu nesmie byť prázdny.",language:"Jazyk",title:"Snippet kódu",pathName:"snippet kódu"});